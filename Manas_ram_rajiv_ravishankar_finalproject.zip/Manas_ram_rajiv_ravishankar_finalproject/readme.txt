

how to run:
python naive_bayes.py satellite_training.txt satellite_test.txt histograms 3


python naive_bayes.py satellite_training.txt satellite_test.txt gaussians

python naive_bayes.py satellite_training.txt satellite_test.txt mixtures 3



refrences:
github.com
-------------------------------------------------------------------------------------------------